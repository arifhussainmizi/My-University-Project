
package m2s;

public class M2S {

    
   // public static void main(String[] args) {
        
        
        
   // }
    
}
