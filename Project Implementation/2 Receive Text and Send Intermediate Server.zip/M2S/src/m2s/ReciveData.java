package m2s;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.sql.SQLException;

public class ReciveData extends javax.swing.JFrame {
    static Socket s;
    static ServerSocket ss;
    static InputStreamReader isr;
    static BufferedReader br; 
     static String message; 
    String imei;
    
    public ReciveData() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        txtArea = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtArea.setColumns(20);
        txtArea.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        txtArea.setRows(5);
        jScrollPane1.setViewportView(txtArea);

        jLabel1.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        jLabel1.setText("Receive Text  :");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(101, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    public static void main(String args[]) throws SQLException, SocketException {
       DbConnector db=new DbConnector();
        java.awt.EventQueue.invokeLater(new Runnable() {
          
            public void run() {
                new ReciveData().setVisible(true);     
            }
        });
        try {
            String imei;
            ss= new ServerSocket(6000);
            
            while(true){
            
                s= ss.accept();
                isr=new InputStreamReader(s.getInputStream());
                br= new BufferedReader(isr);
                message =br.readLine();
                
                String[]parts=message.split("-*-");
                
               imei=parts[2];
               String reciveIp=parts[4];

              //  System.out.println(message);
                //
                if(txtArea.getText().toString().equals(""))
                {
                   txtArea.setText(parts[0]);
                   db.insertData(parts[0],parts[2],parts[4]); 
                }else{
                    txtArea.setText(txtArea.getText()+"\n"+parts[0]); 
                    db.insertData(parts[0],parts[2],parts[4]); 
                }
            }                   

        }catch(IOException e){

            e.printStackTrace();

        }      
        
       
    }
    
     

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private static javax.swing.JTextArea txtArea;
    // End of variables declaration//GEN-END:variables
}
