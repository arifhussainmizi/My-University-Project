
package m2s;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DbConnector {
     private Connection con;
     
     public DbConnector() throws SQLException
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");  

             con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/project_database","root","");
             //con=(Connection) DriverManager.getConnection("jdbc:mysql://https://databases-auth.000webhost.com/localhost:3306/project_database","id4725651_arif","arifcosma");
            System.out.println("Connection successful");
        } catch (Exception e) {
            e.printStackTrace();
        }
    
    }
    
     public  void insertData(String msg, String imei, String ip) throws SQLException
    {
    try{
        
    Statement stmt=con.createStatement();  
    
   String query = " insert into collect_info (message, IMEI, ip_address)" + " values (?, ?, ?)";
    //String query = " insert into project_file (	file_location, imei, ip_address)" + " values (?, ?, ?)";
    
    
      PreparedStatement preparedStmt = con.prepareStatement(query);
      preparedStmt.setString (1, msg);
      preparedStmt.setString(2, imei);
      preparedStmt.setString   (3, ip);
      //preparedStmt.setBoolean(4, false);
      //preparedStmt.setInt    (5, 5000);

      // execute the preparedstatement
      preparedStmt.execute();
      
      //con.close();
    }
    
  /* ResultSet rs=stmt.executeQuery("select * from student_info"); 
    
    
    while(rs.next())  
        System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(4));  
    }  */
     catch(Exception e)
        { 
            
            System.out.println("Not insert   "+e);
        }  
}  
}
