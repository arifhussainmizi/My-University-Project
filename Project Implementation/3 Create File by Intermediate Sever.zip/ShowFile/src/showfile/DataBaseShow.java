
package showfile;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DataBaseShow {
         private Connection con;
         String message;
         String imei;
     public DataBaseShow() throws SQLException
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");  

             con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/project_database","root","");
            System.out.println("Connection successful");
        } catch (Exception e) {
            e.printStackTrace();
        }
    
    }
     
     public void select() throws SQLException
     {
      String query = "SELECT * FROM collect_info";
      
      // create the java statement
      Statement st = con.createStatement();
      
      // execute the query, and get a java resultset
      ResultSet rs = st.executeQuery(query);
      StringBuilder sb=new StringBuilder();
      // iterate through the java resultset
      while (rs.next())
      {
          imei=rs.getString("IMEI");
        message+=" ";
       message += rs.getString("message");
       
      // sb.append(message);
        
        
      }
       WritingFile www=new WritingFile(message,imei);
      st.close();
         System.out.println("message "+message);
    
     
}
     
     }
     
     
     
     

