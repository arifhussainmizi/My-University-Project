
package showfile;


import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;

import java.io.OutputStreamWriter;
import java.io.Writer;



public class WritingFile {
    
    public WritingFile(String message, String imei)
    {
        String fileName="EncryptedFile"+"_"+imei+".txt";
    Writer writer = null;

try {
    writer = new BufferedWriter(new OutputStreamWriter(
          new FileOutputStream(fileName), "utf-8"));
    writer.write(message);
} catch (IOException ex) {
    // Report
} finally {
   try {writer.close();} catch (Exception ex) {/*ignore*/}
}
    }
    
    
    
}
