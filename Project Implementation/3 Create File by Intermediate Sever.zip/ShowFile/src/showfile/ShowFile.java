
package showfile;

import java.sql.SQLException;


public class ShowFile {

    public static void main(String[] args) throws SQLException {
        DataBaseShow db=new DataBaseShow();
       db.select();
       
      // SendCloudServer sf=new SendCloudServer(); 
      // sf.setVisible(true); 
       
      // newhtml.setVisible(true); 
       
    }
    
}
