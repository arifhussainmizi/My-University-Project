package complete.process;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class CompleteProcess {
    public static void main(String[] args) {
        
        String st="Hello, Everyone.";  
        char[] charArray = st.toCharArray(); 
        char[] tempCharArray=st.toCharArray(); 
        char[] asciiChar=new char[charArray.length]; 
        char[] keyAsciiChar=new char[charArray.length];
        int[] asciiInt=new int[charArray.length];
        int[] keyAsciiInt=new int[charArray.length];
        int[] chiperTextInt=new int[charArray.length];
        char[] chiperTextChar=new char[charArray.length]; 
        
        System.out.print("Text: "+st+"\n"); 
                
        ///Shuffle
        shuffleArray(charArray); 

        String tempString= String.valueOf(charArray); 
        
        /// get key or Index number 
        int i=0, j=0; int[] a;  
        a=new int [charArray.length];
        for( i = 0; i < charArray.length; i++ ){
                for(j=0; j<charArray.length;j++)
                {
                   if( tempCharArray[i]==charArray[j])
                   {a[i]=j;}
                }
        }
        
        ///print key
        System.out.print("\nKey: ");
        for(i=0; i<charArray.length; i++)
        {System.out.print(a[i]);}
        
        /////get ASCII Value
        for(i=0; i<charArray.length;i++)
        {asciiChar[i]=tempString.charAt(i); 
         asciiInt[i]=asciiChar[i]; 
        }
        //////// ASCII + Key Value 
        for(i=0; i<charArray.length; i++)
        {chiperTextInt[i]=asciiInt[i]+a[i];} 
        
        System.out.println("Encrypted Text: ");
       ////Print Encrypted text
        for(i=0; i<charArray.length;i++)
        {System.out.print(chiperTextInt[i]);}
         
        
        ////Decrypt process
        int[] dchiperInt;
        dchiperInt=new int[charArray.length];
        char[] dChar= new char[charArray.length]; 
        String[] dSt=new String[charArray.length]; 
        String[] exString=new String[charArray.length];  
        
        for(i=0; i<charArray.length;i++)
       {dchiperInt[i]=chiperTextInt[i];
        dchiperInt[i]=dchiperInt[i]-a[i];
       }
        ///Get agin ASCII Value
        for(i=0; i<charArray.length;i++)
       {
           dChar[i]=(char) dchiperInt[i]; 
           dSt[i]=Character.toString(dChar[i]);         
       }
        
        ///print Original Text
        System.out.print("\nOriginal Text: ");
        
        int l=0; 
        for(int k=0; k<charArray.length; k++){
            for(i=0; i<charArray.length; i++){
               if(a[k]==i)
               {exString[k]=dSt[i];}
            } 
        }
        for(i=0; i<charArray.length; i++)
            {System.out.print(exString[i]);}
    
      
    }
    
    
    /////Shuffle function
    static void shuffleArray(char[] ar)
        {
          Random rnd = ThreadLocalRandom.current();
          for (int i = ar.length - 1; i > 0; i--)
          { int index = rnd.nextInt(i+1 );
            // Simple swap
            int a = ar[index];
            ar[index] = ar[i];
            ar[i] = (char) a;
          }
        }    
}
